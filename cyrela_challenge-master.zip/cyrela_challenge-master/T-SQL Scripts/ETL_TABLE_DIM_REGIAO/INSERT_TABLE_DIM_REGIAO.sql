/****** Script do comando SelectTopNRows de SSMS  ******/
SELECT TOP (1000) [Sk]
      ,[Id]
      ,[Regiao]
  FROM [ChallengeFiapCyrela].[dbo].[Dimensao_Regiao]